/**
 * Googleカレンダー → SheetDoc「ライブスケジュール」シート取り込みスクリプト
 *
 * 【使い方】
 * 1. 取り込み先のスプレッドシートを開き、「拡張機能 > Apps Script」で
 *    このファイルの内容を貼り付ける
 * 2. 下の CALENDAR_ID と SHEET_NAME を自分のものに書き換える
 *    （カレンダーIDは Googleカレンダーの「設定 > カレンダーの設定 > 統合」にある
 *    「カレンダーID」。自分のメインカレンダーならメールアドレスそのもの）
 * 3. 【移行だけなら】migrateFromCalendar() を一度だけ実行すれば完了
 *    （初回だけGoogleの承認画面が出る）。今日から2年先までの予定を
 *    まるごと取り込む。以後はシート側で管理する（カレンダーとは同期しない）
 * 4. 【カレンダー運用を続ける場合のみ】setupTrigger() を一度だけ実行すると
 *    1時間ごとに importEvents() が自動実行される
 *
 * 【取り込みルール】
 * - 対象は「今日 〜 指定ヶ月先」までの予定（過去分は表示側で自動的に隠れるため取り込まない）
 * - 定期予定（毎週・毎月など）は、期間内の1回ずつの予定に展開されて取り込まれる
 * - シートは実行のたびにまるごと書き換える。移行後は「シートが正本」、
 *   定期取り込み運用中は「編集はカレンダー側」がルールになる
 * - カレンダーの説明欄に「出演：〜」「料金：〜」と書いた行は、それぞれ
 *   出演者・料金の列に振り分ける。「開場：18:00」と書けば時間列に OPEN として反映。
 *   残りの行は備考にまとめる
 */

const CALENDAR_ID = 'xxxxxxxx@group.calendar.google.com'; // ← カレンダーIDに書き換え
const SHEET_NAME = 'events';   // ← 書き込み先のシート（タブ）名
const MONTHS_AHEAD = 6;        // 定期取り込み時に何ヶ月先まで取り込むか

// 移行用：今日から2年先までを一度だけ取り込む（以後はシートで管理）
function migrateFromCalendar() {
  doImport(24);
}

// 定期取り込み用：今日から MONTHS_AHEAD ヶ月先までを取り込む
function importEvents() {
  doImport(MONTHS_AHEAD);
}

function doImport(monthsAhead) {
  const cal = CalendarApp.getCalendarById(CALENDAR_ID);
  if (!cal) throw new Error('カレンダーが見つかりません: ' + CALENDAR_ID);

  const tz = Session.getScriptTimeZone();
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setMonth(end.getMonth() + monthsAhead);

  const events = cal.getEvents(start, end);
  const rows = [['日付', 'イベント名', '出演者', '時間', '料金', '備考']];

  events.forEach(ev => {
    const d = ev.getStartTime();
    const dateStr = Utilities.formatDate(d, tz, 'yyyy/M/d');

    // 説明欄（HTMLの場合があるのでタグを落として行に分解）
    const desc = (ev.getDescription() || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '');
    let acts = '', price = '', openTime = '', notes = [];
    desc.split('\n').forEach(line => {
      const t = line.trim();
      if (!t) return;
      if (/^出演[:：]/.test(t)) acts = t.replace(/^出演[:：]\s*/, '');
      else if (/^料金[:：]/.test(t)) price = t.replace(/^料金[:：]\s*/, '');
      else if (/^開場[:：]/.test(t)) openTime = t.replace(/^開場[:：]\s*/, '');
      else notes.push(t);
    });

    let timeStr = '';
    if (!ev.isAllDayEvent()) {
      const startStr = Utilities.formatDate(d, tz, 'H:mm');
      timeStr = openTime ? ('OPEN ' + openTime + ' / START ' + startStr) : ('START ' + startStr);
    }

    rows.push([dateStr, ev.getTitle() || '', acts, timeStr, price, notes.join(' ')]);
  });

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  sheet.clearContents();
  sheet.getRange(1, 1, rows.length, 6).setValues(rows);
  Logger.log(events.length + ' 件の予定を取り込みました');
}

function setupTrigger() {
  // 同じ関数のトリガーが残っていれば消してから作り直す（二重実行防止）
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'importEvents') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('importEvents').timeBased().everyHours(1).create();
  Logger.log('1時間ごとの自動取り込みを設定しました');
}
