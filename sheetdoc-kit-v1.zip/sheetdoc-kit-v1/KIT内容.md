# SheetDoc CMS キット v1（2026-11-15 時点）

## 最初に読むもの
- `setup_buyer.md` — セットアップ手順（この順に進めれば公開できます）
- `README.md` — 仕組みとブロックの仕様
- `manual_owner.md` — 店主・運営者向けの更新マニュアル（納品時に渡すもの）
- `terms.md` — 利用条件

## 本体
- `index.html` — サイト本体（静的HTML 1枚、v1.0）。CONFIG に公開URLを貼って使います

## サンプル集（examples/）
- `livehouse.html` — ライブハウス向けサンプル（ダークテーマ、デモデータ内蔵）
- `theme-demo.html` — テーマ切替の試作用（ライブハウス題材、画面下のバーで3テーマ比較）
- `theme-demo-shop.html` — 小規模店舗向けデモ（和モダン）
- `theme-demo-film.html` — 自主制作映画向けデモ（ダーク）
- `theme-demo-radio.html` — コミュニティ放送向けデモ（スタンダード、番組表つき）
- `fm-taman.html` — 放送向けの応用例（実際の番組表シート参照タイプ）
- `calendar_to_sheet.gs` — Googleカレンダーからシートへの一括移行スクリプト（必要な場合のみ）

## サンプルデータ（samples/）
各ブロックのシートの雛形CSV（menu / hours / events / screenings / credits / quotes / news / gallery / charges / links / map）

## 含まれないもの
- 実案件（groove）のファイル一式は含みません
